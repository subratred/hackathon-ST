package com.hackathon.ShipmentTracker.dao;

//package com.hackathon.ShipmentTracker.dao;
//
//
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface ProdDetailsRepo extends CrudRepository{
//
////	@Query("select c from Customer c where c.email = :email")
////    Stream<Customer> findByEmailReturnStream(@Param("email") String email);
//}
