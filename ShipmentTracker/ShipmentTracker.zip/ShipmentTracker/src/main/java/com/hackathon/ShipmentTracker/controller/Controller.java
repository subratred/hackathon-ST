package com.hackathon.ShipmentTracker.controller;

import java.sql.SQLException;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hackathon.ShipmentTracker.dao.ShipmentTrackDAO;
import com.hackathon.ShipmentTracker.model.OrderStats;
import com.hackathon.ShipmentTracker.model.ServiceResponse;
import com.hackathon.ShipmentTracker.service.ShipmentTrackService;

@RestController
public class Controller {
	@Autowired
	ShipmentTrackService shipmentTrackService;
	@Autowired
	ShipmentTrackDAO dao;

	@RequestMapping(value="/test/{param}",produces="application/json",method=RequestMethod.GET)
	public ServiceResponse gettest(@PathVariable String param) throws Exception{
		ServiceResponse response=shipmentTrackService.trackOrder("1081217112448");
		System.out.println(param);
		return response;
	}
	
	@RequestMapping(value="/fetchData",produces="application/json",method=RequestMethod.GET)
	public ServiceResponse fetchData() throws Exception{
		ServiceResponse response=shipmentTrackService.fetchData();
		System.out.println();
		return response;
	}
	
	@RequestMapping(value="/fetchLocations",produces="application/json",method=RequestMethod.GET)
	public ServiceResponse fetchLocations() throws Exception{
		ServiceResponse response=shipmentTrackService.fetchDistinctLocation();
		System.out.println();
		return response;
	}
	
	@RequestMapping(value="/saveOrders",produces="application/json",method=RequestMethod.POST,consumes="application/json")
	public ServiceResponse saveOrders(@RequestBody OrderStats orderStats) throws Exception{
		ServiceResponse response=shipmentTrackService.saveOrder(orderStats);
		System.out.println();
		return response;
	}
	
	@RequestMapping(value="/openOrders",produces="application/json",method=RequestMethod.GET)
	public ServiceResponse openOrders() throws Exception{
		ServiceResponse response=shipmentTrackService.openOrders();
		System.out.println();
		return response;
	}
	
	@RequestMapping(value="/orderDetails",produces="application/json",method=RequestMethod.GET)
	public ServiceResponse orderDetails() throws Exception{
		ServiceResponse response=shipmentTrackService.orderDetails();
		System.out.println();
		return response;
	}
	
	@RequestMapping(value="/cancelOrder",produces="application/json",method=RequestMethod.GET)
	public ServiceResponse cancelOrder() throws Exception{
		ServiceResponse response=shipmentTrackService.orderDetails();
		System.out.println();
		return response;
	}
	
	@RequestMapping(value="/fetchLocation",produces="application/json",method=RequestMethod.GET)
	public ServiceResponse fetchLocation() throws Exception{
		ServiceResponse response=shipmentTrackService.fetchDistinctLocation();
		System.out.println();
		return response;
	}
	
	@RequestMapping(value="/trackOrder/{param}",produces="application/json",method=RequestMethod.GET)
	public ServiceResponse trackOrder(@PathVariable String orderId) throws Exception{
		ServiceResponse response=shipmentTrackService.trackOrder("1081217112448");
		System.out.println(orderId);
		return response;
	}
}
