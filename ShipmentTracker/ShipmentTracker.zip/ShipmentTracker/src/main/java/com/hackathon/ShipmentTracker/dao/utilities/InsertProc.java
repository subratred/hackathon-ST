package com.hackathon.ShipmentTracker.dao.utilities;

import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.hackathon.ShipmentTracker.model.OrderStats;

public class InsertProc extends StoredProcedure{

	private static final String PROC_NAME = "PRC_INSERT_USER_MASTER";

    public InsertProc(JdbcTemplate jdbcTemplate) {
        super(jdbcTemplate,PROC_NAME);

        //declaraction of parameters
        declareParameter(new SqlParameter("P_USER_ID", java.sql.Types.VARCHAR));
        declareParameter(new SqlParameter("P_LOCATION", java.sql.Types.VARCHAR));
        declareParameter(new SqlParameter("P_MOBILE_NUMBER", java.sql.Types.VARCHAR));
        declareParameter(new SqlParameter("P_DELIVERY_TYPE", java.sql.Types.VARCHAR));
        
        declareParameter(new SqlOutParameter("P_ERR_MSG", java.sql.Types.VARCHAR));
    }
    public Map<String, Object> execute(OrderStats orderStats) {
        Map<String, Object>  params = new HashMap<>();
        params.put("P_USER_ID", orderStats.getUserId());
        params.put("P_LOCATION", orderStats.getDestination());
        params.put("P_MOBILE_NUMBER", orderStats.getMobileNo().toString());
        params.put("P_DELIVERY_TYPE", orderStats.getDeliveryType());

        Map<String, Object> response=super.execute(params);
		return response;
    }
	
}
