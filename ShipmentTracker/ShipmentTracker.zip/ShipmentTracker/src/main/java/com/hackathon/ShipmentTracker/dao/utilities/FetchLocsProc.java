package com.hackathon.ShipmentTracker.dao.utilities;

import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlInOutParameter;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.hackathon.ShipmentTracker.model.OrderStats;

public class FetchLocsProc extends StoredProcedure{

	private static final String PROC_NAME = "PRC_FETCH_LOC";

    public FetchLocsProc(JdbcTemplate jdbcTemplate) {
        super(jdbcTemplate,PROC_NAME);

        //declaraction of parameters
        declareParameter(new SqlParameter("P_ORD_ID", java.sql.Types.VARCHAR));
        declareParameter(new SqlOutParameter("P_FETCH_LOC", java.sql.Types.REF_CURSOR));
        declareParameter(new SqlOutParameter("P_ERR_MSG", java.sql.Types.VARCHAR));
    }
    public Map<String, Object> execute(OrderStats orderStats) {
        Map<String, Object>  params = new HashMap<>();
        params.put("P_ORD_ID", 89561L);
        params.put("P_FETCH_LOC", 1L);
        params.put("P_ERR_MSG", 1L);

        Map<String, Object> response=super.execute(params);
		return response;
    }
	
}
