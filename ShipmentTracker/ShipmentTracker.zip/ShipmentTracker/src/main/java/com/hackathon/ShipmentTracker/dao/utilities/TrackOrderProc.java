package com.hackathon.ShipmentTracker.dao.utilities;

import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

public class TrackOrderProc extends StoredProcedure{

	private static final String PROC_NAME = "PRC_TRACK_ORDER";

    public TrackOrderProc(JdbcTemplate jdbcTemplate) {
        super(jdbcTemplate,PROC_NAME);

        //declaraction of parameters
        declareParameter(new SqlParameter("P_ORD_ID", java.sql.Types.VARCHAR));
        declareParameter(new SqlOutParameter("P_TRACKE_ORD", java.sql.Types.REF_CURSOR));
        declareParameter(new SqlOutParameter("P_ERR_MSG", java.sql.Types.VARCHAR));
    }
    public Map<String, Object> execute(String orderId) {
        Map<String, Object>  params = new HashMap<>();
        params.put("P_ORD_ID", orderId);
//        params.put("P_TRACKE_ORD", 1L);
//        params.put("P_ERR_MSG", 1L);

        Map<String, Object> response=super.execute(params);
        System.out.println(response);
		return response;
    }
	
}
